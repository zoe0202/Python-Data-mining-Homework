score=float(input("成绩="))
#90分及以上为优秀，60分及以上至20分为及格，六十分以下为不及格
if score>=90:
    grade="优秀"
elif score>=60:
    grade="及格"
else:
    grade="不及格"
print("学生评级为：",format(grade))