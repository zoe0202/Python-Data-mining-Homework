a=int(input("请输入一个整数:"))
b=int(input("请输入一个整数："))
if a>b:
    c=b
else:
    c=a
for i in range(1,c):
    if a%c==0 and b%c==0 and c!=1 :
        print("此两数不是互质数")
        break
    else:
        print("此两数为互质数")
