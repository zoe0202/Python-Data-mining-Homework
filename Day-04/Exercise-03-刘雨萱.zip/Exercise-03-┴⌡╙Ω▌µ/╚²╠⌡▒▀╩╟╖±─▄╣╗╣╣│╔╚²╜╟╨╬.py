a=float(input("a="))
b=float(input("b="))
c=float(input("c="))
if a+b>c and a+c>b and b+c>a:
    print("此三边长可以构成三角形")
else:
    print("此三边长不可构成三角形")