n=int(input("请输入一个正整数："))
if n<=2:
    print("%d不是质数"%n)
else:
    for i in range(2,n):
        if n%i==0:
            print("%d不是质数"%n)
            break
    else:
        print("%d是质数"%n)