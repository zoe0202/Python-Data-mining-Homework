inter=input("请输入您的互动量：")
supp=input("请输入您的粉丝量：")
inter=float(inter)
supp=float(supp)
E=inter/supp
print("您的有效互动比为{:.2f}".format(E))