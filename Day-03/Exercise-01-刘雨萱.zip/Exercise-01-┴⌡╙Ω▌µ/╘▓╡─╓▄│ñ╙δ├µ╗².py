import math
r = input("请输入您计算机的半径(保留两位小数)：")
r = float(r)
pi = math.pi
c = 2 * pi * r
s = r ** 2 * pi
print ("该圆的周长为{:.2f}，该圆的面积为{:.2f}".format(c,s))
